// export const BASE_URL = '/app/dashboard/default';
export const BASE_URL = '/auth/signin';
export const BASE_TITLE = ' DigiiHost Dev Panel';

export const CONFIG = {
  layout: 'vertical'
};
