import React, { useState, useEffect, useRef, useMemo, } from "react";
import { MdEmail, MdPhone, MdLocationOn } from 'react-icons/md'
import { useParams, useNavigate } from 'react-router-dom';

import './App.css'

const App = () => {

  const { id } = useParams();
    const isEdit = !!id;

    const [filepreview, setfilepreview] = useState('');
    const [filepreview1, setfilepreview1] = useState('');
    
    const [packageform, setPackageform] = useState({
      pagename: "",
      title: "",
      subtitle:"",
      date: "",
      bgimage: "",
      logo: "",
      email: "",
      contact: "",
      location: "",
  });

    const getdata = async () =>{
      try {

          const response = await fetch(`${import.meta.env.VITE_APP_API_URL}/api/comingsoon/getdata/${id}`, {
              method: "GET",
              headers: {
                  'Content-Type': 'application/json',
              },
          });

          const res_data = await response.json();
          const firstItem = Array.isArray(res_data.msg) && res_data.msg.length > 0
          ? res_data.msg[0]
          : null;
      
      if (firstItem) {
          setPackageform({
              pagename: firstItem.pagename,
              title: firstItem.title,
              subtitle:firstItem.subtitle,
              date: firstItem.date,
              email: firstItem.email,
              contact: firstItem.contact,
              location: firstItem.location,
          });
          setfilepreview(`${import.meta.env.VITE_APP_API_URL}/comingsoon/${firstItem.bgimage}`);
          setfilepreview1(`${import.meta.env.VITE_APP_API_URL}/comingsoon/${firstItem.logo}`);
          console.log(filepreview1);

      }
      } catch (error) {
          console.error("Error fetching options:", error);
      }
  }

  const [timeLeft, setTimeLeft] = useState({
    days: 60,
    hours: 0,
    minutes: 0,
    seconds: 0
  })

  

  useEffect(() => {
      getdata();
  }, []); 

useEffect(() => {
    if (!packageform.date) return; 

    const launchDate = new Date(packageform.date);
    launchDate.setDate(launchDate.getDate()); 

    const calculateTimeLeft = () => {
        const now = new Date();
        const difference = launchDate.getTime() - now.getTime();

        if (difference > 0) {
            setTimeLeft({
                days: Math.floor(difference / (1000 * 60 * 60 * 24)),
                hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
                minutes: Math.floor((difference / 1000 / 60) % 60),
                seconds: Math.floor((difference / 1000) % 60)
            });
        } else {
            setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        }
    };

    calculateTimeLeft(); 
    const timer = setInterval(calculateTimeLeft, 1000); 

    return () => clearInterval(timer);
}, [packageform.date]);

  return (
    <div className="coming-soon">
      <div className="background-overlay" style={{ backgroundImage: `url(${filepreview})` }}></div>
      <div className="content">
        <img 
          src={filepreview1} 
          alt="Company Logo" 
          height="100px"
          className="logo"
        />
        <h1>{packageform.title}</h1>
        <p className="description">
        {packageform.subtitle}
        </p>
        <div className="countdown">
          {['Days', 'Hours', 'Minutes', 'Seconds'].map((label, index) => (
            <div className="countdown-box" key={index}>
              <h2>{Object.values(timeLeft)[index]}</h2>
              <p>{label}</p>
            </div>
          ))}
        </div>
        <div className="contact-info">
          <div className="contact-item">
            <MdEmail size={24} />
            <span>{packageform.email}</span>
          </div>
          <div className="contact-item">
            <MdPhone size={24} />
            <span>{packageform.contact}</span>
          </div>
          <div className="contact-item">
            <MdLocationOn size={24} />
            <span>{packageform.location}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App
