const GoogleStrategy = require("passport-google-oauth20").Strategy;
const FacebookStrategy = require("passport-facebook").Strategy;

const passport = require("passport");
const User = require("./models/customer-model.js"); // Adjust based on your model

passport.use(
    new GoogleStrategy(
        {
            clientID: "222496374727-mf90m1mgt0qsgc9rmmufclh0utnaoodr.apps.googleusercontent.com",
            clientSecret: "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",
            callbackURL: "/api/auth/google/callback",
            scope: ["profile", "email"], // Ensure scope is correctly set
        },
        async (accessToken, refreshToken, profile, done) => {
            try {
                let user = await User.findOne({ googleId: profile.id });
                if (!user) {
                     const password = `${profile.displayName}@2021`;

                    user = new User({
                        googleId: profile.id,
                        username: profile.displayName,
                        email: profile.emails[0].value,
                        password:password,
                        avatar: profile.photos[0].value,
                    });
                    await user.save();
                }
                return done(null, user);
            } catch (error) {
                return done(error, null);
            }
        }
    )
);

passport.use(
    new FacebookStrategy(
      {
        clientID:"2023927851414145",
        clientSecret: "f1a4201e83a7acfbf22c4001b4a6e398",
        callbackURL: "http://localhost:5000/api/auth/facebook/callback",
        profileFields: ["id", "displayName", "emails", "photos"],
      },
      async (accessToken, refreshToken, profile, done) => {
        try {
            let user = await User.findOne({ facebookId: profile.id });
            if (!user) {
                 const password = `${profile.displayName}@2021`;

                user = new User({
                    facebookId: profile.id,
                    username: profile.displayName,
                    email: profile.emails[0].value,
                    password:password,
                    avatar: profile.photos[0].value,
                });
                await user.save();
            }
            return done(null, user);
        } catch (error) {
            return done(error, null);
        }
      }
    )
  );

passport.serializeUser((user, done) => {
    done(null, user.id);
});

passport.deserializeUser(async (id, done) => {
    const user = await User.findById(id);
    done(null, user);
});
