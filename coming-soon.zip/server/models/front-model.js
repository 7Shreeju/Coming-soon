const {Schema, model} = require("mongoose");

// const customSchema = new Schema({
//     title: {type: String, required: true},
//     category:{type: String, required: true},
//     // date:{type: String, required: true},
//     js:{type: String},
//     css:{type: String},
//     details:{type: String},
//     status:{type: String},
// });
// const Custom = new model('Custom',customSchema);


// module.exports = { Custom};